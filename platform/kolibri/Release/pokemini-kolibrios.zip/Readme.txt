========================
PokeMini 0.60 for KolibriOS
========================
Port for KolibriOS by gameblabla

PokeMini is a Pokémon mini emulator by JustBurn.
It has been ported to the PCs, Sega Dreamcast, PSP, NDS
with unofficial ports for the GCW0, TI Nspire and now the KolibriOS.

This requires at least a Pentium Pro to even work.
Why ? Because the toolchain was compiled for Pentium Pro+ support only... (SERGE!)

Sound is supported too, your soundcard needs to support Mono 44050hz 8bits.
I think that shouldn't be a problem as even a SB16 supports that...

To open a ROM, you need to use the "Open with..." thingy.
Choose a Pokémon Mini ROM for that and choose to open it with PokéMini.

Enjoy !
