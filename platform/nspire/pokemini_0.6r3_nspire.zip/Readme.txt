========================
PokeMini 0.6 Release 3
========================
TI-Nspire port by gameblabla

PokeMini is a Pokemon Mini emulator by JustBurn.
It can emulate all the Pokemon Mini games with great accuracy and speed.

This TI-Nspire port runs fullspeed, even when not overclocked, and comes with the game "Physhic Seeds",
a homebrew game by JustBurn.

Release 3 fixes several issues that previous version had.
Now, you only need to transfer one file, pokemini.tns.

=============
Controls
==============
(Can be reconfigured by the way)

Dpad : Touchpad
A : CTRL
B : SHIFT
Start : DEL
Power : Menu
